package com.junior.EXC2.data.retrofit.response

import com.junior.EXC2.model.Cinenote

data class ListCinenoteResponse(

    val notes:List<Cinenote>
)
